Adds the Canon CR3 Sensor Importer update site to Fiji’s updater. Its **CR3 Sensor Data...** import command opens supported Canon RAW and C-RAW files as a Bayer mosaic with one unsigned 16-bit sample per sensor site. It requires Java 21 or later.

- [Plugin documentation](https://imagej.net/plugins/canon-cr3-sensor-importer)
- [Update-site database](https://carstenartur.github.io/Photographer/fiji/cr3/db.xml.gz)
