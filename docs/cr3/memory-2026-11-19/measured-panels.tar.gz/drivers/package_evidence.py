#!/usr/bin/env python3
"""Package completed CR3 memory evidence without rebuilding or rerunning it.

Run only after the coordinator has ended the quiet measurement window:
    python3 package_evidence.py --execute --output REPO/docs/cr3/memory-2026-11-19

The input records are immutable evidence. Their bytes, including failed runs,
are preserved in deterministic archives. No JAR, class, or raw image is copied.
"""
import argparse
from collections import Counter, defaultdict
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import re
import statistics
import sys
import tarfile
import zipfile
import zlib


SCHEMA_VERSION = 1
PUBLICATION_DATE = "2026-11-19"
PROBE_CLASS = "com/photographer/focusstack/cr3/benchmark/Cr3ImportProbe.class"
BASELINE_SHA = "256f089e8d33a12303ccf234cfd3b4d2d119f662fa24078188f9e0b0b1eb7b2f"
FINAL_SHA = "55c44c673b3a9dee8e32c0b05e8148fec39669a29c1f4e072374e2c93af2ec3e"
HELPER21_SHA = "b61f16c33db9e468a79870dbbb19a2405b68f7371ca8d45399f3a879a5bf2806"
HELPER25_SHA = "2ceef1202ab7a1170c15899696018352caef0550c2dcb6c092eb8765e1e10994"
HELPER_SOURCE_SHA = "f2e34987a770acc5f6e35c8d021cd6b8216cab5793d94086308aff104f13d1fa"
PUBLIC_RUNTIME_HEAD = "26a020291c759e64ee1effef38c544d828219856"
PUBLIC_RUNTIME_TREE = "19d41ab3bb089992f902c780401083402065445b"
PUBLIC_RUNTIME_MERGE = "14fafdc3fbc3dd25793b94c63096cd6abb8d770a"
PUBLIC_HELPER_HEAD = "3cd7f322b8d421aca5d8d2e139fa7d13707d0c5e"
CORRECTNESS_COUNTS = {"correctness": 57, "low-heap": 5, "low-heap-continuation": 14}
PANEL_COUNTS = {
    "destination-measurements": 24,
    "memory-mode-measurements": 48,
    "default-control-measurements": 24,
    "default-g5-confirmation": 10,
    "default-craw-rss-confirmation": 10,
    "scheduling-screen": 24,
    "detail-screen": 24,
}
TEXT_SUFFIXES = {".json", ".csv", ".txt", ".stdout", ".stderr", ".log", ".py", ".java", ".patch", ".md"}
METRICS = ("total_ms", "cpu_ms", "allocated_bytes", "heap_used_bytes")
FINGERPRINT = ("width", "height", "channels", "bits", "fnv1a64")
NAMES = ("G5 X II RAW", "EOS R RAW", "G5 X II C-RAW", "EOS M50 C-RAW")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_record(path, expected=None):
    data = path.read_bytes()
    actual = digest(data)
    require(expected is None or actual == expected, f"Artifact pin mismatch: {path}")
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": actual}


def command_option(command, name, default=None):
    return command[command.index(name) + 1] if name in command else default


def json_rows(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.lstrip().startswith("{")]


def retained_path(root, directory, recorded):
    path = Path(recorded)
    if not path.is_absolute():
        path = root / directory / path
    path = path.resolve()
    require(path.is_relative_to((root / directory).resolve()), f"Record references another evidence directory: {path}")
    require(path.is_file(), f"Missing retained process output: {path}")
    return path


def fingerprint(observation):
    return tuple(observation[key] for key in FINGERPRINT)


def audit_correctness(root, inputs):
    pairs = defaultdict(dict)
    records = []
    source_counts = {}
    for directory, expected_count in CORRECTNESS_COUNTS.items():
        rows = read_json(root / directory / "results.json")
        require(len(rows) == expected_count, f"Incomplete retained set: {directory}")
        for row in rows:
            stdout = retained_path(root, directory, row["stdout"])
            stderr = retained_path(root, directory, row["stderr"])
            error = stderr.read_text(encoding="utf-8")
            command = row["command"]
            warnings = sum(line.startswith("CR3 low-memory:") for line in error.splitlines())
            require(json_rows(stdout) == row["results"], f"stdout/result mismatch: {stdout}")
            require(warnings == row["warning_count"], f"Warning-count mismatch: {stderr}")
            require(command_option(command, "--input") == inputs[row["input"]]["path"], f"Wrong input: {stdout}")
            require(command_option(command, "--mode") == row["mode"], f"Wrong mode: {stdout}")
            require(command_option(command, "--memory-mode") == row["memory_mode"], f"Wrong policy: {stdout}")
            require(int(command_option(command, "--orientation", "0")) == row["orientation"], f"Wrong orientation: {stdout}")
            require(f"-Xmx{row['heap_mib']}m" in command and "--checksum" in command, f"Wrong heap/checksum: {stdout}")
            require(command_option(command, "--warmup") == "0" and command_option(command, "--iterations") == "1",
                    f"Unexpected correctness iteration plan: {stdout}")
            if row["exit_code"] == 0:
                require(len(row["results"]) == 1, f"Wrong result count: {stdout}")
                observation = row["results"][0]
                require(observation["checksum_kind"] == "full-u16le-or-u8", f"Sampled correctness fingerprint: {stdout}")
                require(observation["requested_memory_mode"] == row["memory_mode"]
                        and observation["orientation_override"] == row["orientation"]
                        and observation["mode"] == row["mode"], f"Observed request mismatch: {stdout}")
                require(warnings == int(row["memory_mode"] != "FAST"), f"Unexpected successful-read warning: {stderr}")
                if directory == "correctness":
                    key = (row["input"], row["mode"], row["orientation"])
                    require(row["memory_mode"] not in pairs[key], f"Duplicate correctness variant: {key}")
                    pairs[key][row["memory_mode"]] = fingerprint(observation)
            else:
                require(not row["results"] and "java.lang.OutOfMemoryError: Java heap space" in error,
                        f"Unexpected retained failure: {stderr}")
                require(warnings == int(row["memory_mode"] == "AUTO"), f"Unexpected failed-read warning: {stderr}")
            records.append((directory, row, error))
        source_counts[directory] = {
            "processes": len(rows), "successful": sum(row["exit_code"] == 0 for row in rows),
            "failed": sum(row["exit_code"] != 0 for row in rows),
        }
    require(len(pairs) == 28, "Expected 28 full-fingerprint pairs")
    for key, variants in pairs.items():
        require(set(variants) == {"FAST", "LOW_MEMORY"} and variants["FAST"] == variants["LOW_MEMORY"],
                f"Full numeric fingerprint mismatch: {key}")
    numeric_samples = sum(variants["FAST"][0] * variants["FAST"][1] * variants["FAST"][2]
                          for variants in pairs.values())
    require(numeric_samples == 1_806_502_864, "Numeric-sample total changed")
    attempts = defaultdict(dict)
    failures = []
    rescues = []
    for directory, row, error in records:
        if directory == "correctness" and row["exit_code"] == 0:
            continue
        collector = "G1" if "-XX:+UseG1GC" in row["command"] else "Serial"
        key = (row["input"], row["mode"], collector, row["heap_mib"], row["orientation"])
        require(row["memory_mode"] not in attempts[key], f"Duplicate low-heap attempt: {key}")
        attempts[key][row["memory_mode"]] = row
        if row["memory_mode"] == "AUTO" and row["exit_code"] != 0:
            failures.append({
                "input_index": row["input"], "input": NAMES[row["input"]], "mode": row["mode"],
                "collector": collector, "heap_mib": row["heap_mib"], "orientation": row["orientation"],
                "warning_count": row["warning_count"], "stderr_member": f"{directory}/{row['stderr']}",
                "first_project_frame": next(line.strip() for line in error.splitlines()
                                            if line.strip().startswith("at com.photographer")),
            })
    for key, variants in sorted(attempts.items()):
        automatic = variants.get("AUTO")
        if automatic is None or automatic["exit_code"] != 0:
            continue
        control = variants.get("FAST")
        require(control is not None and control["exit_code"] != 0, f"Missing failed FAST control: {key}")
        reference = pairs[(key[0], key[1], key[4])]["FAST"]
        require(fingerprint(automatic["results"][0]) == reference, f"Low-heap/full fingerprint mismatch: {key}")
        rescues.append({
            "input_index": key[0], "input": NAMES[key[0]], "mode": key[1], "collector": key[2],
            "heap_mib": key[3], "orientation": key[4], "warning_count": automatic["warning_count"],
            "fast_control_exit_code": control["exit_code"],
            **dict(zip(FINGERPRINT, reference)),
        })
    require(len(rescues) == 9 and len(failures) == 2, "Retained rescue/failure totals changed")
    warning_counts = Counter((row["memory_mode"], row["exit_code"], row["warning_count"])
                             for _, row, _ in records)
    return {
        "sources": source_counts, "processes": len(records),
        "successful": sum(row["exit_code"] == 0 for _, row, _ in records),
        "oom_failures": sum(row["exit_code"] != 0 for _, row, _ in records),
        "full_fingerprint_pairs": len(pairs), "numeric_samples_per_variant": numeric_samples,
        "numeric_samples_both_variants": 2 * numeric_samples,
        "fingerprint_kind": "Full numeric FNV-1a64; widths, heights, bands and bit depths also compared",
        "heap_rescues": rescues, "retained_auto_failures": failures,
        "warning_counts": [{"policy": key[0], "exit_code": key[1], "warning_count": key[2], "processes": count}
                           for key, count in sorted(warning_counts.items())],
        "notes": ["Caps are successful demonstrations, not minimum heaps.",
                  "Both failed AUTO attempts remain byte-for-byte in the archive.",
                  "Correctness timing fields are incidental and excluded from performance comparisons.",
                  "FAST controls use the same frozen final runtime, not an older release.",
                  "Warnings count only CR3 low-memory messages; separate SLF4J diagnostics are retained."],
    }


def audit_panel(root, directory, expected_processes):
    panel = root / directory
    manifest = read_json(panel / "manifest.json")
    plan = read_json(panel / "plan.json")
    records = read_json(panel / "results.json")
    summary = read_json(panel / "summary.json")
    require(manifest["planned_processes"] == expected_processes == len(plan) == len(records)
            == summary["completed_processes"] == summary["planned_processes"],
            f"Measurement panel is incomplete: {directory}")
    config = manifest["configuration"]
    if directory == "default-craw-rss-confirmation":
        require(config["forks"] == 5 and config["warmup"] == 3 and config["iterations"] == 5,
                "RSS confirmation must preserve the original three-warmup/five-measurement protocol")
    expected_iterations = list(range(config["iterations"]))
    grouped = defaultdict(list)
    for planned, record in zip(plan, records):
        if directory == "default-craw-rss-confirmation":
            require(record["input_index"] == 2 and record["mode"] == "default" and record["cpus"] == 4,
                    "RSS confirmation must contain only the specified G5 X II C-RAW default workload")
        require(record["sequence"] == planned["sequence"] and record["command"] == planned["command"],
                f"Plan/record mismatch: {directory}/{record['sequence']}")
        stdout = retained_path(root, directory, record["stdout"])
        stderr = retained_path(root, directory, record["stderr"])
        require(json_rows(stdout) == record["results"], f"stdout/result mismatch: {stdout}")
        invocation_result = read_json(stdout.parent / "result.json")
        require(invocation_result == record, f"Invocation/root record mismatch: {stdout}")
        exit_record = read_json(stdout.parent / "exit.json")
        require(all(exit_record.get(key) == record.get(key) for key in ("exit_code", "status", "error")),
                f"Invocation exit status mismatch: {stdout}")
        key = tuple(record[name] for name in ("stage", "variant", "input_index", "mode", "cpus"))
        grouped[key].append(record)
        if record["status"] != "ok":
            continue
        require(record["exit_code"] == 0 and [row["iteration"] for row in record["results"]] == expected_iterations,
                f"Incomplete successful observations: {stdout}")
        for row in record["results"]:
            require(row["input"] == record["input"] and row["mode"] == record["mode"]
                    and row["available_processors"] == record["cpus"] and row["warmup"] == config["warmup"]
                    and row["checksum_kind"] == "sampled-rows-u16le-or-u8", f"Observation binding mismatch: {stdout}")
            require(all(isinstance(row.get(metric), (int, float)) and math.isfinite(row[metric])
                        for metric in METRICS), f"Invalid numeric measurement: {stdout}")
        for metric in METRICS:
            actual = statistics.median(row[metric] for row in record["results"])
            require(actual == record["process_summary"]["median"][metric], f"Process median mismatch: {stdout}")
        if directory == "memory-mode-measurements":
            require(all(row["requested_memory_mode"] == record["variant"]
                        and row["orientation_override"] == config["orientation"]
                        and row["workers"] == 0 for row in record["results"]), f"Policy/orientation mismatch: {stdout}")
            warnings = sum(line.startswith("CR3 low-memory:") for line in stderr.read_text().splitlines())
            expected_warnings = config["warmup"] + config["iterations"] if record["variant"] == "LOW_MEMORY" else 0
            require(warnings == expected_warnings == record["warning_count"], f"Repeated-read warning mismatch: {stderr}")
    groups = []
    for key, processes in sorted(grouped.items()):
        good = [record for record in processes if record["status"] == "ok"]
        medians = {metric: [statistics.median(row[metric] for row in record["results"]) for record in good]
                   for metric in METRICS}
        peaks = [max(row["maxrss_kb"] for row in record["results"]) for record in good]
        heap_peaks = [max(row["heap_used_bytes"] for row in record["results"]) for record in good]
        groups.append({
            **dict(zip(("stage", "variant", "input_index", "mode", "cpus"), key)),
            "input": NAMES[key[2]], "processes": len(processes), "successful_processes": len(good),
            "failed_processes": len(processes) - len(good),
            "median_of_process_medians": {metric: statistics.median(values) for metric, values in medians.items() if values},
            "process_medians": medians,
            "median_process_peak_rss_kb": statistics.median(peaks) if peaks else None,
            "process_peak_rss_kb": peaks,
            "process_peak_measured_heap_used_bytes": heap_peaks,
        })
    retained_groups = {tuple(row[name] for name in ("stage", "variant", "input_index", "mode", "cpus")): row
                       for row in summary["groups"]}
    require(len(retained_groups) == len(groups), f"Aggregate group count changed: {directory}")
    for group in groups:
        key = tuple(group[name] for name in ("stage", "variant", "input_index", "mode", "cpus"))
        retained = retained_groups[key]
        require(group["successful_processes"] == retained["successful_processes"]
                and group["failed_processes"] == retained["failed_processes"]
                and group["median_process_peak_rss_kb"] == retained["median_process_peak_rss_kb"]
                and all(value == retained["median_of_process_medians"][metric]
                        for metric, value in group["median_of_process_medians"].items()),
                f"Recomputed aggregate mismatch: {directory}/{key}")
    variants = ("FAST", "LOW_MEMORY") if directory == "memory-mode-measurements" else ("baseline", "final")
    paired = defaultdict(dict)
    for group in groups:
        paired[(group["input_index"], group["mode"], group["cpus"])][group["variant"]] = group
    comparisons = []
    for key, pair in sorted(paired.items()):
        require(set(pair) == set(variants), f"Unpaired measurement group: {directory}/{key}")
        reference, candidate = (pair[variant] for variant in variants)
        comparison = {"input_index": key[0], "input": NAMES[key[0]], "mode": key[1], "cpus": key[2],
                      "reference_variant": variants[0], "compared_variant": variants[1]}
        changes = {}
        for metric in METRICS:
            if metric in reference["median_of_process_medians"] and metric in candidate["median_of_process_medians"]:
                old, new = (group["median_of_process_medians"][metric] for group in (reference, candidate))
                changes[metric] = {"reference": old, "compared": new,
                                   "ratio": new / old if old else None,
                                   "change_percent": 100 * (new / old - 1) if old else None}
        old, new = reference["median_process_peak_rss_kb"], candidate["median_process_peak_rss_kb"]
        if old is not None and new is not None:
            changes["median_process_peak_rss_mib"] = {
                "reference": old / 1024, "compared": new / 1024,
                "ratio": new / old if old else None, "change_percent": 100 * (new / old - 1) if old else None,
            }
        comparisons.append({**comparison, "metrics": changes})
    return {"processes": len(records), "planned_decodes": manifest["planned_decodes"],
            "successful_processes": sum(record["status"] == "ok" for record in records),
            "failed_processes": sum(record["status"] != "ok" for record in records),
            "configuration": config, "groups": groups, "comparisons": comparisons,
            "sampling": "Median of process medians; each process peak RSS includes warmups and VM overhead"}


def test_report(log, class_name):
    pattern = (r"Tests run: (\d+), Failures: (\d+), Errors: (\d+), Skipped: (\d+).*? -- in "
               + re.escape(class_name) + r"(?:\r?$)")
    matches = re.findall(pattern, log, flags=re.MULTILINE)
    require(len(matches) == 1, f"Missing or duplicate test summary: {class_name}")
    return dict(zip(("tests", "failures", "errors", "skipped"), map(int, matches[0])))


def audit_validation(root, correctness, panels):
    integration = read_json(root / "integration-counts.json")
    sums = {key: sum(row[key] for row in integration["counts"]) for key in ("tests", "failures", "errors", "skipped")}
    require(sums == integration["total"] == {"tests": 719, "failures": 0, "errors": 0, "skipped": 1},
            "Integration test totals do not match the retained 719-case gate")
    log = (root / "memory-integration.log").read_text(errors="replace")
    dng = test_report(log, "com.photographer.focusstack.dng.imageio.Cr3DngRoundTripIT")
    packaged = test_report(log, "com.photographer.focusstack.cr3.imageio.CanonCr3ExternalConsumptionIT")
    helper = test_report((root / "probe-reviewed-green.log").read_text(errors="replace"),
                         "com.photographer.focusstack.cr3.benchmark.Cr3ImportProbeTest")
    require(dng == {"tests": 2, "failures": 0, "errors": 0, "skipped": 0}, "DNG round-trip count changed")
    require(packaged == {"tests": 1, "failures": 0, "errors": 0, "skipped": 0}, "Packaged consumer count changed")
    require(helper == {"tests": 24, "failures": 0, "errors": 0, "skipped": 0}, "Final helper test count changed")
    ci = {}
    for number in (426, 427, 428):
        directory = root / f"ci-{number}"
        path = directory / "final-snapshot.json"
        final = path.is_file()
        if not final:
            require(number == 428, f"Missing final CI snapshot for PR {number}")
            path = directory / "initial-snapshot.json"
        snapshot = read_json(path)
        workflows = snapshot.get("workflows", [])
        if number == 427:
            require(snapshot["pr"]["head"] == PUBLIC_RUNTIME_HEAD
                    and snapshot["pr"]["headTree"] == PUBLIC_RUNTIME_TREE, "Public runtime source pin mismatch")
        ci[str(number)] = {"snapshot_member": str(path.relative_to(root)), "final_snapshot": final,
                           "observed_at": snapshot["observedAt"], "pr_at_observation": snapshot["pr"],
                           "workflows": [{key: row.get(key) for key in ("name", "head", "status", "conclusion", "url")}
                                         for row in workflows],
                           "note": "Historical snapshot; merge state at observation is not a statement of current PR state"}
    return {
        "schema_version": SCHEMA_VERSION,
        "integration_gate": {**integration, "included_in_719": {"dng_round_trip_cases": dng,
                                "packaged_imageio_case": packaged}},
        "separate_final_helper_gate": {**helper, "public_pr_head": PUBLIC_HELPER_HEAD,
                                       "note": "Includes later null-decoder regression; frozen measurement helper had 23 green cases"},
        "ci_snapshots": ci,
        "evidence_checks": {"recorded_process_outputs_match": True, "all_required_panels_complete": True,
                            "full_fingerprint_pairs": correctness["full_fingerprint_pairs"],
                            "original_auto_failures_preserved": len(correctness["retained_auto_failures"]),
                            "measurement_aggregates_recomputed": True,
                            "panel_counts": {name: {key: data[key] for key in
                                                   ("processes", "successful_processes", "failed_processes")}
                                             for name, data in panels.items()}},
        "scope": ["Retained evidence is inspected; no test, build or decode is executed by this packager.",
                  "Two DNG round-trip cases and one packaged ImageIO case are included in 719, not added again.",
                  "The 24-case final helper gate is separate from the 719-case integration gate."],
    }


def add_file(members, path, name):
    require(path.is_file() and not path.is_symlink(), f"Missing or nonregular source: {path}")
    require(path.suffix.lower() in TEXT_SUFFIXES, f"Refusing binary/unrecognized archive member: {path}")
    require(name not in members and not Path(name).is_absolute() and ".." not in Path(name).parts,
            f"Duplicate or unsafe archive member: {name}")
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), f"Evidence is still changing: {path}")
    members[name] = {"data": data, "source": path, "stat": (after.st_size, after.st_mtime_ns)}


def add_tree(members, root, relative):
    directory = root / relative
    require(directory.is_dir(), f"Missing evidence directory: {directory}")
    for path in sorted(directory.rglob("*")):
        if path.is_file() or path.is_symlink():
            add_file(members, path, str(path.relative_to(root)))


def archive_inputs(root, output):
    correctness, measured, rejected = {}, {}, {}
    for name in CORRECTNESS_COUNTS:
        add_tree(correctness, root, name)
    for number in (426, 427, 428):
        add_tree(correctness, root, f"ci-{number}")
    for name in (
        "check_full_imports.py", "check_low_heap.py", "check_low_heap_continuation.py", "inputs.json",
        "baseline-manifest.json", "final-probe-build-binding.json", "integration-counts.json",
        "baseline-build.log", "memory-red.log", "memory-green-final.log", "memory-integration.log",
        "imageio-root-verification.log", "probe-red-tests.log", "probe-green-tests.log",
        "probe-malformed-red.log", "probe-reviewed-green.log", "probe-package.log",
        "correctness.log", "low-heap.log", "low-heap-continuation.log",
    ):
        add_file(correctness, root / name, name)
    for name in ("destination-measurements", "memory-mode-measurements", "default-control-measurements",
                 "default-g5-confirmation", "default-craw-rss-confirmation"):
        add_tree(measured, root, name)
        add_file(measured, root / f"{name}.log", f"{name}.log")
    for name in ("public_measurements.py", "measure_memory_modes.py", "inputs.json",
                 "baseline-manifest.json", "final-probe-build-binding.json", "Cr3ImportProbe-normal.java",
                 "sources/Cr3DestinationProbe.java", "sources/memory/Cr3ImportProbe.java",
                 "frozen-probe/binding.json", "frozen-probe/Cr3ImportProbe.java"):
        add_file(measured, root / name, name)
    add_file(measured, Path(__file__).resolve(), "drivers/package_evidence.py")
    for name in ("scheduling-screen", "detail-screen"):
        add_tree(rejected, root, name)
        add_file(rejected, root / f"{name}.log", f"{name}.log")
    for name in ("scheduling-benchmark-binding.json", "detail-benchmark-binding.json",
                 "scheduling-baseline-tests.log", "scheduling-red-tests.log", "scheduling-green-tests.log",
                 "scheduling-package.log", "detail-characterization.log", "detail-mutation-red.log",
                 "detail-codec-tests.log", "detail-java21-tests.log", "detail-benchmark-build.log",
                 "public_measurements.py", "inputs.json", "baseline-manifest.json",
                 "frozen-probe/binding.json", "frozen-probe/Cr3ImportProbe.java"):
        add_file(rejected, root / name, name)
    for name in ("scheduling.patch", "bounded-detail.patch"):
        add_file(rejected, output / "experiments" / name, "experiments/" + name)
    return {"correctness.tar.gz": correctness, "measured-panels.tar.gz": measured,
            "rejected-experiments.tar.gz": rejected}


def write_archive(path, members):
    with path.open("wb") as stream:
        with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name, entry in sorted(members.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(entry["data"])
                    info.mode, info.uid, info.gid, info.mtime = 0o644, 0, 0, 0
                    info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(entry["data"]))
    inventory = [{"path": name, "bytes": len(entry["data"]), "sha256": digest(entry["data"])}
                 for name, entry in sorted(members.items())]
    with tarfile.open(path, "r:gz") as archive:
        require(archive.getnames() == [row["path"] for row in inventory], f"Archive member mismatch: {path}")
        for row in inventory:
            info = archive.getmember(row["path"])
            require(info.isfile() and info.mode == 0o644 and info.uid == info.gid == info.mtime == 0,
                    f"Archive metadata mismatch: {row['path']}")
            data = archive.extractfile(info).read()
            require(len(data) == row["bytes"] and digest(data) == row["sha256"], f"Archived bytes changed: {row['path']}")
    return {"path": path.name, "bytes": path.stat().st_size, "sha256": digest(path.read_bytes()),
            "member_count": len(inventory), "member_bytes": sum(row["bytes"] for row in inventory),
            "members": inventory}


def build_provenance(root, output, archives, documents):
    baseline = read_json(root / "baseline-manifest.json")
    frozen = read_json(root / "final-probe-build-binding.json")
    artifacts = {
        "baseline": file_record(root / "baseline-3f7312c-benchmarks.jar", BASELINE_SHA),
        "frozen_final": file_record(root / "final-benchmarks.jar", FINAL_SHA),
    }
    candidates = {}
    for name, patch in (("scheduling", "scheduling.patch"), ("detail", "bounded-detail.patch")):
        binding = read_json(root / f"{name}-benchmark-binding.json")
        artifacts[name + "_candidate"] = file_record(root / f"{name}-benchmarks.jar", binding["artifact_sha256"])
        candidates[name] = {"local_commit": binding["source_commit"], "local_tree": binding["source_tree"],
                            "base_commit": binding["base_commit"], "published_commit": False,
                            "disposition": "Not integrated", "patch": file_record(output / "experiments" / patch),
                            "artifact": name + "_candidate"}
    with zipfile.ZipFile(root / "final-benchmarks.jar") as jar:
        packed = jar.read(PROBE_CLASS)
    require(digest(packed) == HELPER25_SHA, "Packaged Java 25 helper changed")
    helper21 = file_record(root / "extended-probe21-classes" / PROBE_CLASS, HELPER21_SHA)
    helper25 = file_record(root / "extended-probe-classes" / PROBE_CLASS, HELPER25_SHA)
    source = file_record(root / "sources/memory/Cr3ImportProbe.java", HELPER_SOURCE_SHA)
    supporting_files = []
    for directory in (output / "sources", output / "experiments"):
        for path in sorted(directory.rglob("*")):
            if path.is_file():
                supporting_files.append({**file_record(path), "path": str(path.relative_to(output))})
    return {
        "schema_version": SCHEMA_VERSION, "publication_date": PUBLICATION_DATE,
        "source_history": {
            "baseline_public_commit": baseline["source"],
            "frozen_build_local_base": frozen["source_base_commit"],
            "runtime": {"public_pr": 427, "head": PUBLIC_RUNTIME_HEAD, "tree": PUBLIC_RUNTIME_TREE,
                        "merged_commit": PUBLIC_RUNTIME_MERGE,
                        "relationship": "Measured frozen runtime source is equivalent to the public PR 427 runtime source; helper source is bound separately"},
            "later_helper": {"local_commit_prefix": "c2c591e6", "public_pr": 428, "head": PUBLIC_HELPER_HEAD,
                             "included_in_frozen_binary": False,
                             "change": "Null-decoder guard for malformed orientation input and its regression test"},
            "rejected_candidates": candidates,
        },
        "artifacts": artifacts,
        "helpers": {"frozen_extended_source": source, "java21": {**helper21, "class_major": 65},
                    "java25": {**helper25, "class_major": 69, "packaged_class_sha256": digest(packed)},
                    "class_path_order": "Recorded probe classes precede the runtime JAR; helper hashes are separate from the runtime artifact hash"},
        "inputs": read_json(root / "inputs.json"), "archives": archives, "documents": documents,
        "public_supporting_files": supporting_files,
        "archive_layout": {"root": "Paths are relative to the original qa-memory directory except experiments/ patches and drivers/package_evidence.py",
                           "historical_absolute_paths": "Original manifests and commands retain their exact host paths; they are not rewritten",
                           "excluded": ["JAR files", "compiled classes", "raw input images", "decoded images"],
                           "original_bytes_preserved": True},
        "packaging": {"driver": file_record(Path(__file__).resolve()), "python": sys.version,
                      "zlib_version": zlib.ZLIB_VERSION, "gzip_mtime": 0, "tar_mtime": 0,
                      "tar_uid": 0, "tar_gid": 0, "member_order": "Lexicographic", "verified_after_compression": True,
                      "self_hash": "provenance.json is intentionally excluded from its own hash list; the external package receipt pins every produced file"},
        "notes": ["Build bindings describe the build-time state; later measurements do not rewrite them.",
                  "CI snapshots preserve their observed PR state even when the PR was merged later.",
                  "Input/artifact SHA-256 pins are not output SHA-256 fingerprints.",
                  "No build, test, decoder, compiler, benchmark or network request is launched by this script."],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--execute", action="store_true", help="Required after the coordinator's completion signal")
    parser.add_argument("--replace-generated", action="store_true", help="Replace only the six files owned by this script")
    args = parser.parse_args()
    if not args.execute:
        parser.error("No packaging was performed. Supply --execute only after all measurement workloads have ended.")
    root, output = args.root.resolve(), args.output.resolve()
    inputs = read_json(root / "inputs.json")
    require(len(inputs) == 4, "Expected the four pinned input files")
    correctness = audit_correctness(root, inputs)
    panels = {name: audit_panel(root, name, count) for name, count in PANEL_COUNTS.items()}
    panels["default-g5-confirmation"]["purpose"] = (
        "Targeted confirmation after the original three-fork default-control panel showed a G5 RAW slowdown. "
        "This five-fork panel uses eight warmups and twelve measured imports per process. "
        "The original panel and all its forks remain retained; the two protocols are not pooled.")
    panels["default-craw-rss-confirmation"]["purpose"] = (
        "Targeted RSS confirmation after the original default-control panel showed a G5 X II C-RAW "
        "process-peak RSS increase and transient larger post-import heap observations. Five fresh forks "
        "retain the original three-warmup/five-measured-import protocol. The original panel remains "
        "unchanged and the two panels are not pooled. The allocation control differed by only eight "
        "bytes per import; the cause of the heap/RSS excursions is unresolved. Output fingerprints "
        "and allocation totals alone do not establish a collector diagnosis or extra per-import pixel work.")
    panels["default-craw-rss-confirmation"]["interpretation"] = (
        "The initial high final-variant RSS/heap excursions did not recur in these five follow-up processes. "
        "Their cause was not isolated, and this result does not establish a universal RAM bound. "
        "Time values in this panel are retained diagnostics for the RSS investigation.")
    validation = audit_validation(root, correctness, panels)
    groups = archive_inputs(root, output)
    previous_provenance = output / "provenance.json"
    if args.replace_generated and previous_provenance.is_file():
        previous = read_json(previous_provenance)
        data_directories = set(CORRECTNESS_COUNTS) | set(PANEL_COUNTS)
        for archive_name, old_archive in previous["archives"].items():
            for old_member in old_archive["members"]:
                name = old_member["path"]
                if name.split("/", 1)[0] in data_directories:
                    require(name in groups[archive_name], f"Repack would remove original evidence: {name}")
                    data = groups[archive_name][name]["data"]
                    require(len(data) == old_member["bytes"] and digest(data) == old_member["sha256"],
                            f"Original evidence bytes changed since previous package: {name}")
    results = {
        "schema_version": SCHEMA_VERSION, "publication_date": PUBLICATION_DATE,
        "correctness": correctness,
        "measured_panels": {name: panels[name] for name in (
            "destination-measurements", "memory-mode-measurements", "default-control-measurements",
            "default-g5-confirmation", "default-craw-rss-confirmation")},
        "rejected_experiments": {name: {**panels[name], "disposition": "Not integrated"}
                                 for name in ("scheduling-screen", "detail-screen")},
        "comparison_convention": "change_percent = 100 * (compared/reference - 1); positive time is slower, negative memory is lower",
    }
    owned_names = [*groups, "results-summary.json", "validation.json", "provenance.json"]
    require(args.replace_generated or not any((output / name).exists() for name in owned_names),
            "Generated destination files already exist; use --replace-generated only for an intentional repack")
    # All completion and source checks precede any publication writes.
    output.mkdir(parents=True, exist_ok=True)
    staging = output / ".evidence-packaging"
    require(not staging.exists(), f"A prior unfinished staging directory exists: {staging}")
    staging.mkdir()
    try:
        archives = {name: write_archive(staging / name, members) for name, members in groups.items()}
        for members in groups.values():
            for entry in members.values():
                now = entry["source"].stat()
                require((now.st_size, now.st_mtime_ns) == entry["stat"], f"Source changed during packaging: {entry['source']}")
        documents = {}
        for name, value in (("results-summary.json", results), ("validation.json", validation)):
            data = json_bytes(value)
            (staging / name).write_bytes(data)
            documents[name] = {"path": name, "bytes": len(data), "sha256": digest(data)}
        provenance = build_provenance(root, output, archives, documents)
        (staging / "provenance.json").write_bytes(json_bytes(provenance))
        for name in owned_names:
            (staging / name).replace(output / name)
    finally:
        for path in staging.iterdir():
            path.unlink()
        staging.rmdir()
    receipt = {
        "schema_version": SCHEMA_VERSION, "output": str(output),
        "produced_files": [{**file_record(output / name), "path": name} for name in sorted(owned_names)],
        "archive_inventory": {name: {key: value for key, value in record.items() if key != "members"}
                              for name, record in archives.items()},
        "public_files_at_packaging": [{**file_record(path), "path": str(path.relative_to(output))}
                                       for path in sorted(output.rglob("*")) if path.is_file()],
        "note": "README and supporting files are read for inventory only; this script never writes them",
    }
    (root / "package-receipt.json").write_bytes(json_bytes(receipt))
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
