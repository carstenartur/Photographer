#!/usr/bin/env python3
"""Full numeric fingerprints and constrained-heap checks; timing is not benchmark evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
INPUTS = json.loads((ROOT / "inputs.json").read_text())
OUTPUT = ROOT / "low-heap-continuation"
OUTPUT.mkdir(exist_ok=False)
JAR = ROOT / "final-benchmarks.jar"
HELPER = ROOT / "extended-probe21-classes"
MAIN = "com.photographer.focusstack.cr3.benchmark.Cr3ImportProbe"
records = []
COLLECTOR = "Serial"


def run(index, mode, policy, orientation, heap=512, expected="ok"):
    name = f"{len(records):03d}-i{index}-{mode}-{policy}-o{orientation}-m{heap}"
    cmd = ["/usr/bin/java", "-Xms24m", f"-Xmx{heap}m", f"-XX:+Use{COLLECTOR}GC", "-XX:ActiveProcessorCount=4",
           "-Djava.awt.headless=true", "-cp", str(HELPER) + ":" + str(JAR), MAIN,
           "--input", INPUTS[index]["path"], "--mode", mode, "--memory-mode", policy,
           "--warmup", "0", "--iterations", "1", "--checksum"]
    if orientation:
        cmd += ["--orientation", str(orientation)]
    started = time.time()
    result = subprocess.run(cmd, text=True, capture_output=True, timeout=90)
    (OUTPUT / (name + ".stdout")).write_text(result.stdout)
    (OUTPUT / (name + ".stderr")).write_text(result.stderr)
    observations = [json.loads(s) for s in result.stdout.splitlines() if s.startswith("{")]
    item = dict(input=index, mode=mode, memory_mode=policy, orientation=orientation, heap_mib=heap,
                expected=expected, collector=COLLECTOR, command=cmd, started_epoch=started, exit_code=result.returncode,
                stdout=name + ".stdout", stderr=name + ".stderr", results=observations,
                warning_count=sum(line.startswith("CR3 low-memory:") for line in result.stderr.splitlines()))
    records.append(item)
    (OUTPUT / "results.json").write_text(json.dumps(records, indent=2) + "\n")
    print(name, result.returncode, "warnings", item["warning_count"], flush=True)
    if expected == "oom":
        assert result.returncode != 0 and "OutOfMemoryError" in result.stderr, result.stderr
        assert item["warning_count"] == 0, item
        return None
    assert result.returncode == 0 and len(observations) == 1, result.stderr
    assert item["warning_count"] == (0 if policy == "FAST" else 1), item
    o = observations[0]
    assert o["checksum_kind"] == "full-u16le-or-u8", o
    return tuple(o[k] for k in ("width", "height", "channels", "bits", "fnv1a64"))


reference = {}
previous = json.loads((ROOT / "correctness/results.json").read_text())
for item in previous:
    if item["exit_code"] == 0 and item["memory_mode"] == "FAST":
        o = item["results"][0]
        reference[(item["input"], item["mode"], item["orientation"])] = tuple(o[k] for k in ("width", "height", "channels", "bits", "fnv1a64"))
for COLLECTOR, cases in (("Serial", ((1,"rgb16",224),(2,"rgb16",144),(3,"rgb16",184))), ("G1", ((0,"rgb16",144),(1,"rgb16",208),(2,"rgb16",144),(3,"rgb16",176)))):
    for i, mode, heap in cases:
        assert run(i, mode, "AUTO", 6, heap) == reference[(i,mode,6)]
        run(i, mode, "FAST", 6, heap, "oom")
summary = dict(processes=len(records), successful=sum(x["exit_code"]==0 for x in records), expected_oom=sum(x["expected"]=="oom" for x in records), full_fingerprints_match=True, notes=["Caps are successful demonstrations, not minimum heaps.", "Original AUTO failures at96MiB RGB8 and208MiB SerialRGB16 remain in prior records."])
(OUTPUT / "summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary),flush=True)
