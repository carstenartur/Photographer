# PR 427 CI verification

Observed: 2026-11-19T11:43:49.924Z
Checks completed as observed: 2026-11-19T11:43:20.486Z
Head: 26a020291c759e64ee1effef38c544d828219856
Tree: 19d41ab3bb089992f902c780401083402065445b
Base: 264ae80ce88c2b51f35a24dba83b2f3cb5c21fcb
PR: https://github.com/carstenartur/Photographer/pull/427

All six workflow runs completed successfully on attempt 1. All 14 exact-head check-runs completed: 11 success and 3 configured skips. No failures, pending runs, obsolete branch runs, legacy commit-status entries or additional merge-test checks were observed.
Final PR snapshot: state=open; merged=false; mergeable=true; mergeable_state=clean.

## Workflow runs

| Workflow | Run | Event | Result |
| --- | --- | --- | --- |
| CR3 Research Integration | [44515027825](https://github.com/carstenartur/Photographer/actions/runs/44515027825) | pull_request | success |
| CR3 Benchmark History | [44515027784](https://github.com/carstenartur/Photographer/actions/runs/44515027784) | pull_request | success |
| CR3 Fiji distribution | [44515027867](https://github.com/carstenartur/Photographer/actions/runs/44515027867) | pull_request | success |
| CR3 Packaged Consumer | [44515027913](https://github.com/carstenartur/Photographer/actions/runs/44515027913) | pull_request | success |
| CI | [44515027854](https://github.com/carstenartur/Photographer/actions/runs/44515027854) | pull_request | success |
| Automatic Dependency Submission (Maven) | [44515020620](https://github.com/carstenartur/Photographer/actions/runs/44515020620) | dynamic | success |

## Exact-head check-runs

| Check | Check/run job | Result |
| --- | --- | --- |
| Scheduled Maven Site & Badges | [135532198290](https://github.com/carstenartur/Photographer/actions/runs/44515027854/job/135532198290) | skipped |
| Docker Build Smoke Test | [135532196056](https://github.com/carstenartur/Photographer/actions/runs/44515027854/job/135532196056) | success |
| Publish the released Fiji update site | [135530353650](https://github.com/carstenartur/Photographer/actions/runs/44515027867/job/135530353650) | skipped |
| attach | [135530353356](https://github.com/carstenartur/Photographer/actions/runs/44515027867/job/135530353356) | skipped |
| bundle | [135528962380](https://github.com/carstenartur/Photographer/actions/runs/44515027867/job/135528962380) | success |
| Frontend Test, Lint & Build | [135528769134](https://github.com/carstenartur/Photographer/actions/runs/44515027854/job/135528769134) | success |
| Maven verification | [135528769098](https://github.com/carstenartur/Photographer/actions/runs/44515027854/job/135528769098) | success |
| Detect documentation-only changes | [135528705687](https://github.com/carstenartur/Photographer/actions/runs/44515027854/job/135528705687) | success |
| CR3 research integration tests | [135528704868](https://github.com/carstenartur/Photographer/actions/runs/44515027825/job/135528704868) | success |
| Resolve Fiji build source | [135528704360](https://github.com/carstenartur/Photographer/actions/runs/44515027867/job/135528704360) | success |
| CR3 external Maven consumer and Central bundle | [135528704224](https://github.com/carstenartur/Photographer/actions/runs/44515027913/job/135528704224) | success |
| JMH Benchmarks (Canon CR3) | [135528704166](https://github.com/carstenartur/Photographer/actions/runs/44515027784/job/135528704166) | success |
| Calibrate unchanged CR3 sentinels | [135528703690](https://github.com/carstenartur/Photographer/actions/runs/44515027784/job/135528703690) | success |
| submit-maven | [135528686565](https://github.com/carstenartur/Photographer/actions/runs/44515020620/job/135528686565) | success |

Maven verification and Docker Build Smoke Test have no failed steps. Docker image construction, browser-runtime installation and packaged-application Chromium smoke completed successfully. Release attachment/publication and scheduled site generation were skipped for this pull-request event.

Monitoring used read-only GitHub connector calls. No local builds, retries, comments, merges or other public mutations were performed. This completion snapshot was written once after all applicable workflows completed.
