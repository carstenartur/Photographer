# PR 426 CI verification

Observed: 2026-11-19T11:26:52.211Z
Head: 1b559c2e1a565517adf0ff1fd57490abe6173e0c
PR: https://github.com/carstenartur/Photographer/pull/426

All five workflow runs completed successfully. All 13 exact-head check-runs completed: 10 success and 3 configured skips. No failures, no pending runs, no obsolete runs on the PR branch, and no legacy commit-status entries. The PR remains open and unmerged; GitHub reports mergeable=true and mergeable_state=clean. All workflow runs are attempt 1.

## Workflow runs

| Workflow | Run | Event | Result |
| --- | --- | --- | --- |
| CR3 Fiji distribution | [44513070279](https://github.com/carstenartur/Photographer/actions/runs/44513070279) | pull_request | success |
| CR3 Packaged Consumer | [44513069716](https://github.com/carstenartur/Photographer/actions/runs/44513069716) | pull_request | success |
| CR3 Benchmark History | [44513069650](https://github.com/carstenartur/Photographer/actions/runs/44513069650) | pull_request | success |
| CI | [44513069677](https://github.com/carstenartur/Photographer/actions/runs/44513069677) | pull_request | success |
| Automatic Dependency Submission (Maven) | [44513060477](https://github.com/carstenartur/Photographer/actions/runs/44513060477) | dynamic | success |

## Exact-head check-runs

| Check | Check/run job | Result |
| --- | --- | --- |
| Scheduled Maven Site & Badges | [135525134849](https://github.com/carstenartur/Photographer/actions/runs/44513069677/job/135525134849) | skipped |
| Docker Build Smoke Test | [135525132032](https://github.com/carstenartur/Photographer/actions/runs/44513069677/job/135525132032) | success |
| Publish the released Fiji update site | [135523420535](https://github.com/carstenartur/Photographer/actions/runs/44513070279/job/135523420535) | skipped |
| attach | [135523419548](https://github.com/carstenartur/Photographer/actions/runs/44513070279/job/135523419548) | skipped |
| bundle | [135522158610](https://github.com/carstenartur/Photographer/actions/runs/44513070279/job/135522158610) | success |
| Frontend Test, Lint & Build | [135522042035](https://github.com/carstenartur/Photographer/actions/runs/44513069677/job/135522042035) | success |
| Maven verification | [135522041915](https://github.com/carstenartur/Photographer/actions/runs/44513069677/job/135522041915) | success |
| Resolve Fiji build source | [135521971250](https://github.com/carstenartur/Photographer/actions/runs/44513070279/job/135521971250) | success |
| JMH Benchmarks (Canon CR3) | [135521969406](https://github.com/carstenartur/Photographer/actions/runs/44513069650/job/135521969406) | success |
| Detect documentation-only changes | [135521969403](https://github.com/carstenartur/Photographer/actions/runs/44513069677/job/135521969403) | success |
| CR3 external Maven consumer and Central bundle | [135521969076](https://github.com/carstenartur/Photographer/actions/runs/44513069716/job/135521969076) | success |
| Calibrate unchanged CR3 sentinels | [135521968860](https://github.com/carstenartur/Photographer/actions/runs/44513069650/job/135521968860) | success |
| submit-maven | [135521944054](https://github.com/carstenartur/Photographer/actions/runs/44513060477/job/135521944054) | success |

Maven verification and Docker Build Smoke Test have no failed steps. Docker image construction, browser-runtime installation and packaged-application Chromium smoke completed successfully. Release attachment/publication and scheduled site generation were skipped for this pull-request event.

Monitoring used read-only GitHub connector calls. No builds were run locally; no retries, comments, merges or other public mutations were performed.
