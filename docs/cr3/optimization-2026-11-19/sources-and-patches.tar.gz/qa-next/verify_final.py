#!/usr/bin/env python3
"""Compare final imports to pinned previous full fingerprints, including tight heaps.

All recorded times are incidental correctness diagnostics, not benchmark results.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--jar', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
out = args.output.resolve()
out.mkdir(exist_ok=False)
inputs = json.loads((ROOT / 'qa-memory/inputs.json').read_text())
old = json.loads((ROOT / 'qa-memory/correctness/results.json').read_text())
probe = ROOT / 'qa-memory/extended-probe21-classes'
main = 'com.photographer.focusstack.cr3.benchmark.Cr3ImportProbe'
fields = ('width', 'height', 'channels', 'bits', 'fnv1a64', 'checksum_kind')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')


reference = {}
for record in old:
    if record['exit_code'] == 0 and record['memory_mode'] == 'FAST':
        row = record['results'][0]
        reference[(record['input'], record['mode'], record['orientation'])] = {k: row[k] for k in fields}
for sample in inputs:
    assert digest(sample['path']) == sample['sha256'], sample['path']

plan = []


def add(index, mode, orientation, policy, heap=512, collector='Serial', expected='ok'):
    plan.append(dict(input=index, mode=mode, orientation=orientation,
                     memory_mode=policy, heap_mib=heap, collector=collector, expected=expected))


for key in sorted(reference):
    for policy in ('FAST', 'LOW_MEMORY'):
        add(*key, policy)
caps = [('Serial', 0, 'rgb8', 128), ('Serial', 0, 'rgb16', 144),
        ('Serial', 1, 'rgb16', 224), ('Serial', 2, 'rgb16', 144),
        ('Serial', 3, 'rgb16', 184), ('G1', 0, 'rgb16', 144),
        ('G1', 1, 'rgb16', 208), ('G1', 2, 'rgb16', 144),
        ('G1', 3, 'rgb16', 176)]
for collector, index, mode, heap in caps:
    add(index, mode, 6, 'AUTO', heap, collector)
for collector, index, mode, heap in (caps[0], caps[-1]):
    add(index, mode, 6, 'FAST', heap, collector, 'oom')

save('manifest.json', dict(created_epoch=time.time(), inputs=inputs,
    driver_sha256=digest(__file__), jar=str(args.jar.resolve()), jar_sha256=digest(args.jar),
    reference_file=str(ROOT / 'qa-memory/correctness/results.json'),
    reference_sha256=digest(ROOT / 'qa-memory/correctness/results.json'),
    probe_sha256=digest(probe / (main.replace('.', '/') + '.class')),
    java_version=subprocess.check_output(['/usr/bin/java', '-version'], stderr=subprocess.STDOUT, text=True),
    note='Fresh process and fresh complete import per case. Full numeric hashes; timing is not performance evidence.'))
save('plan.json', plan)
records = []
for index, case in enumerate(plan):
    stem = f'{index:03d}-i{case["input"]}-{case["mode"]}-{case["memory_mode"]}-o{case["orientation"]}-{case["collector"]}-m{case["heap_mib"]}'
    command = ['taskset', '-c', '0-3', '/usr/bin/java', '-Xms24m', f'-Xmx{case["heap_mib"]}m',
               f'-XX:+Use{case["collector"]}GC', '-XX:ActiveProcessorCount=4', '-Djava.awt.headless=true',
               '-cp', str(probe) + ':' + str(args.jar.resolve()), main, '--input', inputs[case['input']]['path'],
               '--mode', case['mode'], '--memory-mode', case['memory_mode'],
               '--warmup', '0', '--iterations', '1', '--checksum']
    if case['orientation']:
        command += ['--orientation', str(case['orientation'])]
    start = time.time()
    result = subprocess.run(command, capture_output=True, text=True, timeout=120)
    (out / (stem + '.stdout')).write_text(result.stdout)
    (out / (stem + '.stderr')).write_text(result.stderr)
    rows = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
    warnings = [line for line in result.stderr.splitlines() if line.startswith('CR3 low-memory:')]
    record = dict(case, command=command, started_epoch=start, exit_code=result.returncode,
                  stdout=stem+'.stdout', stderr=stem+'.stderr', results=rows,
                  warning_count=len(warnings), warnings=warnings)
    records.append(record)
    save('results.json', records)
    print(stem, result.returncode, 'warnings', len(warnings), flush=True)
    if case['expected'] == 'oom':
        assert result.returncode != 0 and 'OutOfMemoryError' in result.stderr, record
        assert len(warnings) == 0, record
        continue
    assert result.returncode == 0 and len(rows) == 1, record
    assert len(warnings) == (0 if case['memory_mode'] == 'FAST' else 1), record
    identity = {k: rows[0][k] for k in fields}
    key = (case['input'], case['mode'], case['orientation'])
    assert identity == reference[key], (case, identity, reference[key])
save('summary.json', dict(processes=len(records), full_fingerprints_match=True,
    baseline_reference_cases=len(reference), exact_mode_comparisons=2*len(reference),
    constrained_heap_successes=len(caps), expected_fast_oom=2,
    note='Successful caps are demonstrations, not minimum heap requirements; inherited baseline hashes bind source inputs and complete numeric outputs.'))
