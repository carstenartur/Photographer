#!/usr/bin/env python3
"""Build immutable candidate JARs from exact independent git commits."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
HERE = Path(__file__).resolve().parent
WORK = ROOT / "photographer-next-screen"
MAVEN = ROOT / "rgb16-tools/mvn"
variants = [("raw-fusion", "ff7fac6"), ("detail-refill", "d69c3ca"),
            ("grouped-runs", "00fc8c0"), ("encoder", "e8e508d"),
            ("rgb8-rows", "e1dff01"), ("compact-workers", "d0344cb")]
manifest = []
for name, commit in variants:
    if subprocess.check_output(["git", "status", "--porcelain"], cwd=WORK, text=True).strip():
        raise RuntimeError("Screening worktree has uncommitted changes")
    subprocess.run(["git", "switch", "--detach", commit], cwd=WORK, check=True, capture_output=True)
    sha = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=WORK, text=True).strip()
    tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=WORK, text=True).strip()
    command = [str(MAVEN), "-o", "-Pbenchmarks", "-pl", "canon-cr3-benchmark", "-am",
               "-DskipTests", "clean", "package"]
    log = HERE / ("build-" + name + ".log")
    print("Building", name, sha, flush=True)
    start = time.time()
    with log.open("wb") as stream:
        result = subprocess.run(command, cwd=WORK, stdout=stream, stderr=subprocess.STDOUT)
    item = {"variant": name, "commit": sha, "tree": tree, "command": command,
            "cwd": str(WORK), "exit_code": result.returncode, "log": str(log), "started_epoch": start}
    if result.returncode == 0:
        output = HERE / (name + "-benchmarks.jar")
        shutil.copyfile(WORK / "canon-cr3-benchmark/target/benchmarks.jar", output)
        item.update(jar=str(output), bytes=output.stat().st_size,
                    sha256=hashlib.sha256(output.read_bytes()).hexdigest())
    manifest.append(item)
    (HERE / "candidate-builds.json").write_text(json.dumps(manifest, indent=2) + "\n")
    if result.returncode:
        raise RuntimeError("Candidate build failed: " + name)
    print("Frozen", name, item["sha256"], flush=True)
