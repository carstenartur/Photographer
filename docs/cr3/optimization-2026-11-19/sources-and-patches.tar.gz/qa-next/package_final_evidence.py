#!/usr/bin/env python3
"""Package existing CR3 import observations. This command never runs a benchmark or build."""
import argparse
import collections
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile
import tempfile

HERE = Path(__file__).resolve().parent
MEMORY = HERE.parent / "qa-memory"
PUBLIC_BASE = "74812b83df3a226688c0f856c200e6fd3f1cd368"
BASE = "8a64f4a0664f47af4c31e19ca547e35820f40296"
SCREENS = ("raw", "refill", "runs", "encoder", "rows", "memory")
FINALS = ("final-java21", "final-vectors", "final-compact", "final-one-cpu")
PROBE = "com/photographer/focusstack/cr3/benchmark/Cr3ImportProbe"
IDENTITY = ("width", "height", "channels", "bits", "fnv1a64", "checksum_kind")
TEXT = {".json", ".csv", ".txt", ".stdout", ".stderr", ".log"}


def read(path):
    return json.loads(path.read_bytes())


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def git(repo, *args, data=None, env=None):
    return subprocess.run(["git", "-C", str(repo), *args], input=data, env=env,
                          check=True, stdout=subprocess.PIPE).stdout


def revision(repo, expression):
    return git(repo, "rev-parse", "--verify", expression).decode().strip()


def archive(path, entries):
    """Stable metadata and an in-archive SHA-256 for every original byte stream."""
    inventory = {}
    with path.open("wb") as raw, gzip.GzipFile(filename="", fileobj=raw, mode="wb",
                                               compresslevel=6, mtime=0) as zipped:
        with tarfile.open(mode="w|", fileobj=zipped, format=tarfile.GNU_FORMAT) as tar:
            def add(name, data):
                member = tarfile.TarInfo(name)
                member.size = len(data)
                member.mode = 0o644
                tar.addfile(member, io.BytesIO(data))
            for name, source in sorted(entries.items()):
                data = source.read_bytes() if isinstance(source, Path) else source
                add(name, data)
                inventory[name] = sha(data)
            add("SHA256.json", encode(inventory))
    with tarfile.open(path, mode="r:gz") as tar:
        for member in tar:
            data = tar.extractfile(member).read()
            if member.name == "SHA256.json":
                require(json.loads(data) == inventory, "Archive inventory changed")
            else:
                require(sha(data) == inventory[member.name], "Archive member changed: " + member.name)
    return {"file": path.name, "bytes": path.stat().st_size, "sha256": sha(path.read_bytes()),
            "members_excluding_inventory": len(inventory)}


def source_patches(repo, final, sources, stage):
    public_tree = read(HERE / "packaging-publish.json")["base_tree"]
    require(revision(repo, BASE + "^{tree}") == public_tree and
            read(HERE / "packaging-publish.json")["base_public"] == PUBLIC_BASE,
            "Local base does not match the recorded public tree")
    builds = {x["variant"]: x for x in read(HERE / "candidate-builds.json")}
    patches = {}
    parents = {"raw-fusion": None, "detail-refill": "raw-fusion", "grouped-runs": "detail-refill",
               "encoder": None, "rgb8-rows": "encoder", "compact-workers": None, "final-runtime": None}
    for name, prior in parents.items():
        before = builds[prior]["commit"] if prior else BASE
        after = final if name == "final-runtime" else builds[name]["commit"]
        target = revision(repo, after + "^{tree}")
        if name != "final-runtime":
            require(target == builds[name]["tree"], f"{name}: frozen source tree changed")
            require(sha(Path(builds[name]["jar"]).read_bytes()) == builds[name]["sha256"],
                    f"{name}: frozen JAR changed")
        patch = git(repo, "diff", "--binary", "--full-index", "--no-ext-diff", "--no-textconv", before, after)
        require(b"GIT binary patch\n" not in patch, f"{name}: binary patches need explicit artifact review")
        # Check exact reconstruction in an isolated index. The user's checkout and index are untouched.
        env = dict(os.environ, GIT_INDEX_FILE=str(stage / "verification.index"))
        git(repo, "read-tree", before, env=env)
        if patch:
            git(repo, "apply", "--cached", "--binary", "-", data=patch, env=env)
        require(git(repo, "write-tree", env=env).decode().strip() == target,
                f"{name}: patch did not reproduce the frozen tree")
        path = f"patches/{name}.patch"
        sources[path] = patch
        patches[name] = {"source_commit": after, "source_tree": target, "patch": path,
                         "patch_sha256": sha(patch),
                         "apply_in_order_from_public_base": (patches[prior]["apply_in_order_from_public_base"]
                                                              if prior else []) + [path]}
    return {"public_base": PUBLIC_BASE, "public_base_tree": public_tree, "local_equivalent_base": BASE,
            "verification": "Applied each patch to its parent tree in a temporary index and checked git write-tree.",
            "build": "mvn -Pbenchmarks -pl canon-cr3-benchmark -am -DskipTests clean package",
            "rebuild_note": "Tree equality identifies sources. JAR digests identify the exact recorded binary.",
            "patches": patches}


def identity(record, mode):
    shape = {field: record[field] for field in IDENTITY}
    channels = 1 if mode.startswith("sensor") else 3
    bits = 16 if channels == 1 or mode.startswith("rgb16") else 8
    require(shape["width"] > 0 and shape["height"] > 0 and shape["channels"] == channels
            and shape["bits"] == bits and shape["checksum_kind"] == "full-u16le-or-u8"
            and re.fullmatch(r"[0-9a-f]{16}", shape["fnv1a64"]),
            "Invalid output shape, precision or full fingerprint")
    return shape


def panel_audit(panel):
    planned = read(panel / "correctness-plan.json") if (panel / "correctness-plan.json").exists() else []
    rows = read(panel / "correctness.json") if (panel / "correctness.json").exists() else []
    groups = collections.defaultdict(dict)
    errors = []
    for r in rows:
        key = (r["cpus"], r["input_index"], r["mode"])
        try:
            require(r["status"] == "ok" and r["exit_code"] == 0 and len(r["results"]) == 1,
                    "Expected one successful full-image read")
            out = r["results"][0]
            require(out["input"] == r["input"] and out["mode"] == r["mode"]
                    and out["available_processors"] == r["cpus"], "Result identity differs from command")
            require(r["variant"] not in groups[key], "Duplicate variant")
            groups[key][r["variant"]] = identity(out, r["mode"])
        except (KeyError, ValueError, TypeError) as exc:
            errors.append({"sequence": r.get("sequence"), "error": str(exc)})
    expected = collections.defaultdict(list)
    for check in planned:
        expected[check["cpus"], check["input_index"], check["mode"]].append(check["variant"])
    pairs = []
    for key in sorted(set(groups) | set(expected)):
        actual = groups[key]
        values = list(actual.values())
        passed = (len(values) >= 2 and sorted(actual) == sorted(expected[key])
                  and all(v == values[0] for v in values))
        pairs.append({"cpus": key[0], "input_index": key[1], "mode": key[2],
                      "variants": actual, "complete_match": passed})
    return {"planned_processes": len(planned), "recorded_processes": len(rows),
            "all_pairs_verified": bool(pairs) and not errors and all(p["complete_match"] for p in pairs),
            "pairs": pairs, "errors": errors}


def final_audit(folder, reference_file):
    ref = {}
    for r in read(reference_file):
        if r["exit_code"] == 0 and r["memory_mode"] == "FAST":
            ref[r["input"], r["mode"], r["orientation"]] = identity(r["results"][0], r["mode"])
    plan = read(folder / "plan.json") if (folder / "plan.json").exists() else []
    cases = read(folder / "results.json") if (folder / "results.json").exists() else []
    errors = []
    hashes = ooms = 0
    for idx, case in enumerate(cases):
        try:
            require(idx < len(plan) and all(case.get(k) == v for k, v in plan[idx].items()),
                    "Recorded condition differs from plan")
            if case["expected"] == "oom":
                require(case["exit_code"] != 0 and b"OutOfMemoryError" in
                        (folder / case["stderr"]).read_bytes() and case["warning_count"] == 0,
                        "Expected FAST failure did not match")
                ooms += 1
            else:
                require(case["exit_code"] == 0 and len(case["results"]) == 1, "Expected one successful read")
                require(identity(case["results"][0], case["mode"]) ==
                        ref[case["input"], case["mode"], case["orientation"]], "Reference mismatch")
                require(case["warning_count"] == (0 if case["memory_mode"] == "FAST" else 1),
                        "Unexpected compact warning count")
                hashes += 1
        except (KeyError, IndexError, OSError, ValueError, TypeError) as exc:
            errors.append({"index": idx, "error": str(exc)})
    return {"recorded_processes": len(cases), "planned_processes": len(plan),
            "full_reference_matches": hashes, "expected_oom_observed": ooms,
            "all_cases_verified": bool(plan) and len(plan) == len(cases) and not errors, "errors": errors}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True, help="Integration checkout containing the experiment commits")
    parser.add_argument("--final-revision", help="Final measured source revision (default: source_commit in build binding)")
    parser.add_argument("--final-binding", type=Path, default=HERE / "final-build-binding.json")
    parser.add_argument("--output", type=Path, help="Default: REPO/docs/cr3/optimization-2026-11-19")
    args = parser.parse_args()
    repo = args.repo.resolve()
    output = (args.output or repo / "docs/cr3/optimization-2026-11-19").resolve()
    binding = read(args.final_binding)
    final = revision(repo, args.final_revision or binding["source_commit"])
    require(final == revision(repo, binding["source_commit"]) and
            revision(repo, final + "^{tree}") == binding["source_tree"]
            and re.fullmatch(r"[0-9a-f]{64}", binding["jar_sha256"]), "Final build binding differs from source")
    sources, measured, correct = {}, {}, {}
    # Keep the integrated verification evidence with correctness, separate from timing records.
    correct["verification/final-reactor.log"] = HERE / "final-reactor.log"
    correct["verification/build-followup.log"] = HERE / "build-followup.log"
    correct["verification/warning-audit.json"] = HERE / "warning-audit.json"
    if (HERE / "ci-verification.json").exists():
        correct["verification/ci-verification.json"] = HERE / "ci-verification.json"
    for filename in ("freeze_candidates.py", "measure_panel.py", "measure_final.py", "verify_final.py",
                     "candidate-builds.json", "packaged-vector-artifact.json", "packaged-launches.json", "environment.json"):
        sources["qa-next/" + filename] = HERE / filename
    sources["qa-next/final-build-binding.json"] = args.final_binding
    for panel in tuple("screen-" + name for name in SCREENS) + FINALS:
        config = HERE / (panel + ".json")
        if config.is_file():
            sources["qa-next/" + config.name] = config
    for followup in ("build-followup.json", "research-profile-followup.patch"):
        if (HERE / followup).exists():
            sources["qa-next/" + followup] = HERE / followup
    for followup_log in ("research-profile-fixed.log", "processing-default-followup.log"):
        if (HERE / followup_log).exists():
            correct["verification/" + followup_log] = HERE / followup_log
    sources["qa-next/package_final_evidence.py"] = Path(__file__).resolve()
    for filename in ("public_measurements.py", "inputs.json", "frozen-probe/binding.json", "final-probe-build-binding.json"):
        sources["qa-memory/" + filename] = MEMORY / filename
    for p in HERE.glob("candidate-builds*failure.json"):
        sources["qa-next/" + p.name] = p
    for p in HERE.glob("build-*.log"):
        sources["qa-next/" + p.name] = p
    probe_sources = {"normal": (MEMORY / "Cr3ImportProbe-normal.java", read(MEMORY / "frozen-probe/binding.json")["source_sha256"]),
                     "extended-measured": (MEMORY / "sources/memory/Cr3ImportProbe.java",
                                           read(MEMORY / "final-probe-build-binding.json")["probe_source_sha256"])}
    helpers = {}
    for role, (path, pinned) in probe_sources.items():
        require(sha(path.read_bytes()) == pinned, f"{role}: frozen probe source changed")
        name = "probes/" + role + "/Cr3ImportProbe.java"
        sources[name] = path
        helpers[role] = {"path": name, "source_sha256": pinned, "compiled_classes": {}}
        family = "normal" if role == "normal" else "extended"
        for java, dirname in ((25, family + "-probe-classes"), (21, family + "-probe21-classes")):
            data = (MEMORY / dirname / (PROBE + ".class")).read_bytes()
            helpers[role]["compiled_classes"][java] = {"sha256": sha(data), "class_major": int.from_bytes(data[6:8], "big")}
    current_probe = git(repo, "show", final + ":canon-cr3-benchmark/src/main/java/" + PROBE + ".java")
    sources["probes/extended-repository/Cr3ImportProbe.java"] = current_probe
    helpers["extended-repository"] = {"source_sha256": sha(current_probe), "source_commit": final,
                                       "role": "Repository source with later malformed-orientation guard."}

    reference_file = MEMORY / "correctness/results.json"
    correct["qa-memory/correctness/results.json"] = reference_file
    manifests, panel_results, audits, process_counts, issues = {}, {}, {}, {}, []
    required = {"screen-" + n for n in SCREENS} | set(FINALS) | {"final-correctness"}
    # Keep partial attempts and renamed reruns alongside the planned panels.
    folders = [p for p in HERE.iterdir() if p.is_dir() and ((p / "manifest.json").exists()
               or p.name in required or p.name.startswith(("screen-", "final-one-cpu", "final-correctness")))]
    missing = sorted(required - {p.name for p in folders})
    inputs = read(MEMORY / "inputs.json")
    for sample in inputs:
        require(sha(Path(sample["path"]).read_bytes()) == sample["sha256"], "Input SHA mismatch: " + sample["sample"])
    final_bound = set()
    for p in sorted(folders):
        manifest = read(p / "manifest.json") if (p / "manifest.json").exists() else {}
        verification = p.name.startswith("final-correctness") or "reference_file" in manifest
        if not (verification or "config" in manifest or p.name in required or p.name.startswith("screen-")):
            continue
        files = [f for f in p.rglob("*") if f.is_file() and not f.is_symlink() and f.suffix in TEXT]
        for f in files:
            rel = f.relative_to(p)
            is_check = verification or rel.parts[0].startswith("correctness")
            (correct if is_check else measured)["qa-next/" + p.name + "/" + rel.as_posix()] = f
        if verification:
            audits[p.name] = final_audit(p, reference_file)
            if manifest:
                pins = {"driver_sha256": sha((HERE / "verify_final.py").read_bytes()),
                        "probe_sha256": helpers["extended-measured"]["compiled_classes"][21]["sha256"],
                        "reference_sha256": sha(reference_file.read_bytes())}
                for name, val in pins.items():
                    require(manifest[name] == val, f"{p.name}: {name} mismatch")
                if manifest["jar_sha256"] == binding["jar_sha256"]:
                    final_bound.add(p.name)
            continue
        audits[p.name] = panel_audit(p)
        if (p / "summary.json").exists():
            panel_results[p.name] = read(p / "summary.json")
        records = read(p / "results.json") if (p / "results.json").exists() else []
        planned_count = manifest.get("planned_processes")
        process_counts[p.name] = {
            "planned": planned_count, "recorded": len(records),
            "by_status": dict(collections.Counter(r.get("status", "unknown") for r in records)),
            "complete_success": bool(planned_count) and len(records) == planned_count
                                and all(r.get("status") == "ok" for r in records),
        }
        if manifest:
            correct["qa-next/" + p.name + "/manifest.json"] = p / "manifest.json"
            manifests[p.name] = manifest.get("artifacts", {})
            for key, entry in manifests[p.name].items():
                artifact = Path(entry["path"])
                actual = sha(artifact.read_bytes()) if artifact.is_file() else None
                if actual != entry["sha256"]:
                    issues.append({"panel": p.name, "artifact": key, "recorded_sha256": entry["sha256"],
                                   "available_sha256": actual})
                if key == "configuration" and actual == entry["sha256"]:
                    sources["qa-next/" + p.name + "-config.json"] = artifact
                if key == "driver" and actual == entry["sha256"]:
                    sources["qa-next/" + artifact.name] = artifact
                if key in manifest["config"]["variants"] and entry["sha256"] == binding["jar_sha256"]:
                    final_bound.add(p.name)
        config = HERE / (p.name + ".json")
        if config.is_file():
            sources["qa-next/" + config.name] = config

    audit_report = {"fields_compared": IDENTITY,
                    "method": "Read emitted channels explicitly. Original screen drivers used a missing bands key; "
                              "probe independently validates every band's precision. Timed sampled hashes are excluded.",
                    "panels": audits}
    correct["channel-audit.json"] = encode(audit_report)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="cr3-evidence-", dir=output.parent) as temp:
        stage = Path(temp)
        reconstruction = source_patches(repo, final, sources, stage)
        sources["patches/reconstruction.json"] = encode(reconstruction)
        archives = [archive(stage / n, entries) for n, entries in
                    (("measured-panels.tar.gz", measured), ("correctness.tar.gz", correct),
                     ("sources-and-patches.tar.gz", sources))]
        provenance = {"archives": archives, "source_reconstruction": reconstruction, "helpers": helpers,
                      "final_build": binding, "measured_artifacts": manifests,
                      "build_configuration_followup": read(HERE / "build-followup.json")
                          if (HERE / "build-followup.json").exists() else None,
                      "required_panels_missing": missing, "measured_process_counts": process_counts,
                      "final_jar_observed_in": sorted(final_bound),
                      "final_panels_without_final_jar": sorted((set(FINALS) | {"final-correctness"}
                                                                | ({"final-one-cpu"} & set(audits))) - final_bound),
                      "artifact_verification_issues": issues,
                      "inputs": [{"sample": s["sample"], "bytes": s["bytes"], "sha256": s["sha256"]} for s in inputs],
                      "raw_evidence": "All available observations, outliers, failing process records, stdout, stderr "
                                      "and commands are retained. Missing/partial work is visible in plans and summaries."}
        for name, obj in (("provenance.json", provenance), ("channel-audit.json", audit_report),
                          ("results-summary.json", panel_results)):
            (stage / name).write_bytes(encode(obj))
        output.mkdir(parents=True, exist_ok=True)
        deliverables = [a["file"] for a in archives] + ["channel-audit.json", "results-summary.json", "provenance.json"]
        for name in deliverables:
            os.replace(stage / name, output / name)
        print("Evidence written to", output)
        print("Missing panels:", missing, "artifact issues:", len(issues),
              "final JAR missing from:", provenance["final_panels_without_final_jar"])
        print("Failed/incomplete measured panels:", [k for k, v in process_counts.items() if not v["complete_success"]])
        print("Unverified correctness panels:", [k for k, v in audits.items()
              if not v.get("all_pairs_verified", v.get("all_cases_verified", False))])


if __name__ == "__main__":
    main()
