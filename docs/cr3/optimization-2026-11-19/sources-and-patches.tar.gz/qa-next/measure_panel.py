#!/usr/bin/env python3
"""Serial, paired full-import screening with retained commands and raw observations."""
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
spec = importlib.util.spec_from_file_location("measure", ROOT / "qa-memory/public_measurements.py")
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)

config_path = Path(sys.argv[1]).resolve()
config = json.loads(config_path.read_text())
output = HERE / config["name"]
output.mkdir(exist_ok=False)
samples = json.loads((ROOT / "qa-memory/inputs.json").read_text())
indices = config["indices"]
for index in indices:
    sample = samples[index]
    if measure.sha256(Path(sample["path"])) != sample["sha256"]:
        raise RuntimeError("Input fingerprint mismatch")

variants = config["variants"]
java = Path(config.get("java", str(ROOT / "rgb16-tools/jdk-25.0.5.1+2/bin/java")))
probe = Path(config.get("probe_classes", str(ROOT / "qa-memory/normal-probe-classes")))
probe_main = "com.photographer.focusstack.cr3.benchmark.Cr3ImportProbe"
forks = config.get("forks", 3)
warmup = config.get("warmup", 8)
iterations = config.get("iterations", 12)
cpus = config.get("cpus", [4])

def invocation(sequence, index, mode, variant, fork, position, cpu, checksum=False):
    data = variants[variant]
    command = ["taskset", "-c", f"0-{cpu-1}", str(java), "-Xms24m",
               f"-Xmx{config.get('heap_mib', 768)}m", config.get("gc", "-XX:+UseSerialGC"),
               f"-XX:ActiveProcessorCount={cpu}", *data.get("java_args", []),
               "-cp", str(probe) + os.pathsep + data["jar"], probe_main,
               "--input", samples[index]["path"], "--mode", mode,
               "--warmup", str(2 if checksum else warmup),
               "--iterations", str(1 if checksum else iterations), "--gc-between",
               *config.get("probe_args", []), *data.get("probe_args", [])]
    if checksum:
        command.append("--checksum")
    return {"sequence": sequence, "stage": config["name"], "variant": variant,
            "input_index": index, "input": samples[index]["path"], "sample": samples[index]["sample"],
            "mode": mode, "cpus": cpu, "fork": fork, "pair_position": position,
            "command": command, "environment_overrides": {}}

checks = []
for cpu in cpus:
    for index in indices:
        for mode in config["modes"]:
            for position, variant in enumerate(variants, 1):
                checks.append(invocation(len(checks)+1, index, mode, variant, 0, position, cpu, True))
plan = []
for fork in range(1, forks+1):
    order = list(variants) if fork % 2 else list(reversed(variants))
    for cpu in cpus:
        for index in indices:
            for mode in config["modes"]:
                for position, variant in enumerate(order, 1):
                    plan.append(invocation(len(plan)+1, index, mode, variant, fork, position, cpu))
artifacts = {"driver": Path(__file__), "configuration": config_path,
             "common_runner": ROOT / "qa-memory/public_measurements.py", "java": java,
             "probe": probe / (probe_main.replace(".", "/") + ".class")}
artifacts.update({name: Path(value["jar"]) for name, value in variants.items()})
measure.write_json(output / "manifest.json", {"created_utc": measure.utc_now(), "config": config,
    "platform": platform.platform(), "python": sys.version,
    "artifacts": {name: measure.file_record(path) for name, path in artifacts.items()},
    "inputs": [dict(samples[i], index=i) for i in indices],
    "planned_processes": len(plan), "planned_observations": len(plan)*iterations,
    "inherited_runtime_environment": {key: os.environ[key] for key in
       ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS", "LD_LIBRARY_PATH") if key in os.environ},
    "method": "Serial AB/BA/AB fresh processes; fresh read per iteration, warmed filesystem cache. Full numeric fingerprints separately; timed imports retain sampled liveness fingerprints."})
measure.write_json(output / "correctness-plan.json", checks)
measure.write_json(output / "plan.json", plan)

records = []
expected = {}
for check in checks:
    record, interrupted = measure.run_one(check, SimpleNamespace(iterations=1, timeout_seconds=240), output / "correctness")
    records.append(record)
    measure.write_json(output / "correctness.json", records)
    if interrupted or record["status"] != "ok":
        raise RuntimeError("Correctness invocation failed; retained raw evidence")
    row = record["results"][0]
    if row.get("checksum_kind") != "full-u16le-or-u8":
        raise RuntimeError("Full numeric fingerprint was not produced")
    key = (check["cpus"], check["input_index"], check["mode"])
    identity = {key: row.get(key) for key in ("width", "height", "bands", "bits", "fnv1a64", "checksum_kind")}
    if expected.setdefault(key, identity) != identity:
        raise RuntimeError(f"Full numeric fingerprint mismatch: {key}")
print("Full fingerprints matched", len(checks), "processes", flush=True)

records = []
for item in plan:
    print(f"[{item['sequence']}/{len(plan)}] {item['variant']} cpu{item['cpus']} input{item['input_index']} {item['mode']} fork{item['fork']}", flush=True)
    record, interrupted = measure.run_one(item, SimpleNamespace(iterations=iterations, timeout_seconds=300), output)
    records.append(record)
    measure.save_summary(output, records, len(plan))
    print(record["status"], record["process_summary"]["median"].get("total_ms"), flush=True)
    if interrupted or record["status"] != "ok":
        raise RuntimeError("Measurement failed; retained raw evidence")
print("Completed", output, flush=True)
